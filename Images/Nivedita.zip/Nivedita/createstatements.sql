DROP SCHEMA IF EXISTS onlineretail;
CREATE SCHEMA onlineretail;
USE onlineretail;

create table Login(login_Id int NOT NULL,
username varchar(50) NOT NULL,
password varchar(50) NOT NULL,
PRIMARY KEY(login_Id),
UNIQUE(username));

Create table Retailer (
retailer_Id int NOT NULL AUTO_INCREMENT, 
login_Id int NOT NULL,
retailer_First_Name varchar (50) NOT NULL,
retailer_Last_Name varchar (50) NOT NULL, 
email varchar (100),
phone varchar(20),
PRIMARY KEY(retailer_Id),
FOREIGN KEY (login_Id) REFERENCES Login(login_Id));

create table Address( address_Id int NOT NULL,
city varchar(100) NOT NULL,
state varchar(100) NOT NULL,
zipcode int NOT NULL,
country varchar(100),
PRIMARY KEY(address_Id));

create table Customer(customer_Id int NOT NULL,
address_Id int NOT NULL,
login_Id int NOT NULL,
customer_First_Name varchar(50) NOT NULL,
customer_Last_Name varchar(50) NOT NULL,
email varchar(100) NOT NULL,
phone varchar(20)NOT NULL,
PRIMARY KEY(customer_Id),
FOREIGN KEY (login_Id) REFERENCES Login(login_Id),
FOREIGN KEY (address_Id) REFERENCES Address(address_Id));

show tables;

create table Product_Details(product_Id INT NOT NULL,
retailer_Id INT NOT  NULL,
product_Name varchar(100) NOT NULL,
product_Price decimal (8,2) NOT NULL,
product_Category varchar(100) NOT NULL,
product_Description varchar(1024) NOT NULL,
PRIMARY KEY(product_Id),
FOREIGN KEY (retailer_Id) REFERENCES Retailer(retailer_Id));

create table Customer_Wishlist(wishlist_Id int NOT NULL,
product_Id INT NOT NULL,
customer_Id int NOT NULL,
PRIMARY KEY(wishlist_Id),
FOREIGN KEY (product_Id) REFERENCES Product_Details(product_Id),
FOREIGN KEY (customer_Id) REFERENCES Customer(customer_Id));

create table Payment_Details(payment_Id int NOT NULL,
customer_id int NOT NULL,
card_Type varchar(50) NOT NULL,
name_on_Card varchar(100) NOT NULL,
card_Number varchar(50) NOT NULL,
card_Cvv int NOT NULL,
expiry_Date date NOT NULL,
primary key(payment_Id),
FOREIGN KEY (customer_Id) REFERENCES Customer(customer_Id));



create table Order_Item(order_Id int NOT NULL,
customer_Id int NOT NULL,
order_Status varchar(50) NOT NULL,
shipping_Address_Id int NOT NULL,
billing_Address_Id int NOT NULL,
payment_Id int NOT NULL,
order_Amount decimal(8,2) NOT NULL,
order_date date NOT NULL,
primary key(order_Id),
FOREIGN KEY (customer_Id) REFERENCES Customer(customer_Id),
FOREIGN KEY (shipping_Address_Id) REFERENCES Address(address_Id),
FOREIGN KEY (billing_Address_Id) REFERENCES Address(address_Id),
FOREIGN KEY (payment_Id) REFERENCES Payment_Details(payment_Id));

create table Order_Item_Details(order_Details_Id int NOT NULL,
order_Id int NOT NULL,
product_Id int NOT NULL,
product_Quantity int NOT NULL,
primary key(order_Details_Id),
FOREIGN KEY (order_Id) REFERENCES order_Item(order_Id),
FOREIGN KEY (product_Id) REFERENCES Product_Details(product_Id));

create table Order_Return(order_Return_Id int NOT NULL,
order_Id int NOT NULL,
return_Reason varchar(1000) NOT NULL,
return_Status varchar(50) NOT NULL,
return_Amount decimal(8,2) NOT NULL,
product_Id INT NOT NULL,
PRIMARY KEY(order_Return_Id),
FOREIGN KEY (order_Id) REFERENCES order_Item(order_Id),
FOREIGN KEY (product_Id) REFERENCES Product_Details(product_Id));

create table Customer_Feedback(feedback_Id int NOT NULL,
customer_Id int NOT NULL,
order_Id int NOT NULL,
product_Id INT NOT NULL,
product_Rating varchar(15) NOT NULL,
comments varchar(1000) NOT NULL,
PRIMARY KEY(feedback_Id),
FOREIGN KEY (customer_Id) REFERENCES Customer(customer_Id),
FOREIGN KEY (order_Id) REFERENCES order_Item(order_Id),
FOREIGN KEY (product_Id) REFERENCES Product_Details(product_Id));
